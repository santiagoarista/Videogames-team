# Links to assets used in the game

## Used

### Items
https://opengameart.org/content/animated-coins

### Tiles
https://opengameart.org/content/dungeon-crawl-32x32-tiles-supplemental

### Characters
https://opengameart.org/content/blordrough

### Sounds
https://opengameart.org/content/10-8bit-coin-sounds

## Not used

### Tiles
https://opengameart.org/content/roguelike-tiles-large-collection


